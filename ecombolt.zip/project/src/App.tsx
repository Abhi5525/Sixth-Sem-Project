import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetail } from './components/ProductDetail';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { UserAccount } from './components/UserAccount';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { ProductProvider } from './context/ProductContext';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'product' | 'cart' | 'checkout' | 'account' | 'admin'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  const handleViewProduct = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentView('product');
  };

  const handleNavigate = (view: 'home' | 'cart' | 'checkout' | 'account' | 'admin') => {
    setCurrentView(view);
  };

  return (
    <AuthProvider>
      <ProductProvider>
        <CartProvider>
          <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
            <Header 
              onNavigate={handleNavigate}
              currentView={currentView}
            />
            
            <main className="container mx-auto px-4 py-8">
              {currentView === 'home' && (
                <ProductGrid onViewProduct={handleViewProduct} />
              )}
              
              {currentView === 'product' && selectedProductId && (
                <ProductDetail 
                  productId={selectedProductId} 
                  onBack={() => setCurrentView('home')}
                />
              )}
              
              {currentView === 'cart' && (
                <Cart onProceedToCheckout={() => setCurrentView('checkout')} />
              )}
              
              {currentView === 'checkout' && (
                <Checkout onBack={() => setCurrentView('cart')} />
              )}
              
              {currentView === 'account' && (
                <UserAccount />
              )}
              
              {currentView === 'admin' && (
                <AdminPanel />
              )}
            </main>
            
            <Footer />
          </div>
        </CartProvider>
      </ProductProvider>
    </AuthProvider>
  );
}

export default App;