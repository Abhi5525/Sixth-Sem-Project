import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  description: string;
  category: string;
  images: string[];
  inStock: boolean;
  rating: number;
  reviewCount: number;
  sizes?: string[];
  colors?: string[];
  features: string[];
}

interface ProductState {
  products: Product[];
  categories: string[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  getProduct: (id: string) => Product | undefined;
  getProductsByCategory: (category: string) => Product[];
}

const ProductContext = createContext<ProductState | undefined>(undefined);

const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 299.99,
    originalPrice: 399.99,
    description: 'Experience crystal-clear audio with our premium wireless headphones. Featuring active noise cancellation, 30-hour battery life, and premium leather cushions for maximum comfort.',
    category: 'Electronics',
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.8,
    reviewCount: 234,
    colors: ['Black', 'White', 'Silver'],
    features: ['Active Noise Cancellation', '30-hour Battery', 'Quick Charge', 'Premium Materials']
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 249.99,
    description: 'Track your health and fitness goals with this advanced smartwatch. Features heart rate monitoring, GPS tracking, and 7-day battery life.',
    category: 'Electronics',
    images: [
      'https://images.pexels.com/photos/393047/pexels-photo-393047.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/267394/pexels-photo-267394.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.6,
    reviewCount: 189,
    colors: ['Black', 'Rose Gold', 'Silver'],
    features: ['Heart Rate Monitor', 'GPS Tracking', '7-day Battery', 'Water Resistant']
  },
  {
    id: '3',
    name: 'Designer Coffee Mug Set',
    price: 49.99,
    originalPrice: 69.99,
    description: 'Elegant ceramic coffee mug set with unique artistic designs. Perfect for your morning coffee or as a thoughtful gift.',
    category: 'Home & Kitchen',
    images: [
      'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1251175/pexels-photo-1251175.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.7,
    reviewCount: 156,
    features: ['Ceramic Material', 'Dishwasher Safe', 'Set of 4', 'Unique Designs']
  },
  {
    id: '4',
    name: 'Luxury Leather Handbag',
    price: 189.99,
    description: 'Handcrafted luxury leather handbag with premium hardware and spacious interior. Perfect for both professional and casual settings.',
    category: 'Fashion',
    images: [
      'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.9,
    reviewCount: 98,
    colors: ['Brown', 'Black', 'Tan'],
    features: ['Genuine Leather', 'Multiple Compartments', 'Adjustable Strap', 'Premium Hardware']
  },
  {
    id: '5',
    name: 'Professional Camera Lens',
    price: 799.99,
    description: 'High-quality professional camera lens with superior optics and fast autofocus. Perfect for portrait and landscape photography.',
    category: 'Electronics',
    images: [
      'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.8,
    reviewCount: 67,
    features: ['Fast Autofocus', 'Weather Sealed', 'Superior Optics', 'Professional Grade']
  },
  {
    id: '6',
    name: 'Organic Skincare Set',
    price: 79.99,
    originalPrice: 99.99,
    description: 'Complete organic skincare routine with natural ingredients. Includes cleanser, toner, serum, and moisturizer.',
    category: 'Beauty',
    images: [
      'https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    inStock: true,
    rating: 4.5,
    reviewCount: 203,
    features: ['100% Organic', 'Cruelty Free', 'All Skin Types', 'Complete Routine']
  }
];

export const ProductProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(initialProducts);

  const categories = [...new Set(products.map(p => p.category))];

  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct = { ...product, id: Date.now().toString() };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, updatedProduct: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updatedProduct } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const getProduct = (id: string) => {
    return products.find(p => p.id === id);
  };

  const getProductsByCategory = (category: string) => {
    return products.filter(p => p.category === category);
  };

  return (
    <ProductContext.Provider value={{
      products,
      categories,
      addProduct,
      updateProduct,
      deleteProduct,
      getProduct,
      getProductsByCategory
    }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};